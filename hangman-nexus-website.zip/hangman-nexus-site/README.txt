HANGMAN NEXUS - WEBSITE DEPLOYMENT

Your website entry file is index.html.

Publish with Netlify (phone-friendly option):
1. Open https://app.netlify.com/drop in your browser.
2. If prompted, sign in or create a Netlify account.
3. Upload the hangman-nexus-site folder if folder upload is supported, or upload a ZIP of this folder.
4. Netlify will deploy the site and provide a public URL.
5. Open that URL to test the game on your phone.

Alternative: GitHub Pages
1. Create a new GitHub repository.
2. Upload index.html to the repository root.
3. Open repository Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to provide the site URL.

Notes:
- This is a static HTML game; no backend server is required for the core game.
- Progress is stored locally in each visitor's browser, so it does not sync between devices.
- Ads are not configured in this package. Add an ad network only after reviewing its eligibility and policy requirements.
